# Double Elimination
This is a python package to manage the matches for a double elimination tournament.

It doesn't currently handle the grand finals match if the loser wins the first match.

For usage, see the test files.

Create an issue if you have any suggested features, changes, or documentation. Pull requests welcome.

Install with `pip install double_elimination`
